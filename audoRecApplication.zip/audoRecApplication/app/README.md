# AudioRecordingApp
Android app to record mic audio
